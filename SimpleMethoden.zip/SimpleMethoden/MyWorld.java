import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
    }
    
    public void act()
    {
        double num1 = Greenfoot.getRandomNumber(100);
        double num2 = Greenfoot.getRandomNumber(100);
        int ganz1 = Greenfoot.getRandomNumber(100);
        int ganz2 = Greenfoot.getRandomNumber(100);
        double zahlPi = Math.PI;
        
        // Ganze Zahlen
        System.out.println("Multiplikation (int):" + ganz1 + " x " + ganz2 + " = " + multiplikation_int(ganz1,ganz2));
        System.out.println("Division (int): " + ganz1 + " / " + ganz2 + " = " + division_int(ganz1,ganz2));
        System.out.println("Addition (int): " + ganz1 + " + " + ganz2 + " = " + addition_int(ganz1,ganz2));
        System.out.println("Subtraktion (int): " + ganz1 + " - " + ganz2 + " = " + subtraktion_int(ganz1,ganz2));
        
        // isEven (int)
        System.out.println(num1 + " ist eine gerade Zahl: " + isEven(ganz1));
        System.out.println(num2 + " ist eine gerade Zahl: " + isEven(ganz2));
        
        // Kommazahlen
        System.out.println("Multiplikation (double): " + num1 + " x " + num2 + " = " + multiplikation(num1,num2));
        System.out.println("Division (double): " + num1 + " / " + num2 + " = " + division(num1,num2));
        System.out.println("Addition (double): " + num1 + " + " + num2 + " = " + addition(num1,num2));
        System.out.println("Subtraktion (double): " + num1 + " - " + num2 + " = " + subtraktion(num1,num2));
        
        // isEven (double)
        System.out.println(ganz1 + " ist eine gerade Zahl: " + isEven(num1));
        System.out.println(ganz2 + " ist eine gerade Zahl: " + isEven(num2));
        
        // Wurzelrechnung
        System.out.println("Die Wurzel aus 1. Zahl: " + num1 + " = " + sqrt(num1));
        System.out.println("Die Wurzel aus 2. Zahl: " + num2 + " = " + sqrt(num2));
        
        // Zahl PI
        System.out.println("Zahl Pi lautet: " + zahlPi);
        System.out.println("Kreisumfangrechnung: " + "2 x " + "Radius(" + ganz1 + ") x " + "Pi(" + Math.PI + ") = " + umfang(ganz1));
    }
    // Kommazahlen
    public double multiplikation(double number1, double number2)
    {
        return number1 * number2;
    }
    
    public double division(double number1, double number2)
    {
        return number1 / number2;
    }
    
    public double addition(double number1, double number2)
    {
        return number1 + number2;
    }
    
    public double subtraktion(double number1, double number2)
    {
        return number1 - number2;
    }
    
    // Ganze Zahlen
    public int multiplikation_int(int number1, int number2)
    {
        return number1 * number2;
    }
    
    public int division_int(int number1, int number2)
    {
        return number1 / number2;
    }
    
    public int addition_int(int number1, int number2)
    {
        return number1 + number2;
    }
    
    public int subtraktion_int(int number1, int number2)
    {
        return number1 - number2;
    }
    
    //modulo
    public int modulo(int number1, int number2)
    {
        return number1 % number2;
    }
    
    // isEven (int) (=ob die Zahl gerade ist)
    public boolean isEven(int number)
    {
        return number%2 == 0;
    }    
    
    // isEven (double)
    public boolean isEven(double number)
    {
        return number%2 == 0;
    }    
    
    // Wurzelrechnung
    public double sqrt(double num1)
    {
        return Math.sqrt(num1);
    }
    
    // Zahl Pi eingeben
    public double pi(double number)
    {
        return Math.PI*number;
    }
    
    // Kreisumfang eingeben
    public double umfang(double radius)
    {
        return 2*radius*Math.PI;
    }
}