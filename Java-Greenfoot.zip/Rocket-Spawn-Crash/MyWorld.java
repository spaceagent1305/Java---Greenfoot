import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;  // Import the Scanner class

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{   
    String Gruss = "Servus, grieß enk!";
    String myText = "RocketSpawn"; 
    int number = 1; //setze number auf 1
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1);
        getBackground();                  //platziere mein Hintergrund
        addObject(new Rocket(), 50, 130); //erzeuge Rocket 1
        addObject(new Rocket(), 50, 270); //erzeuge Rocket 2
        showText(Gruss, 275, 200);        //zeige Text von der Variable Gruss
    }
    
    public void act()
    {   
        if(Greenfoot.isKeyDown("right")) //wenn Rechts-Taste gedrückt wird
        {
           addObject(new Rocket(), Greenfoot.getRandomNumber(200)+100, Greenfoot.getRandomNumber(250)+100); //x = Zufallszahl zw. 100 & 300; y = Zufallszahl zw. 100 & 350     
           System.out.println(myText + " " + number); //zeige den Text von der Variable myText mit Abstand und den number Wert
           number++;   // zähle immer Eins dazu
        }
    }
}
