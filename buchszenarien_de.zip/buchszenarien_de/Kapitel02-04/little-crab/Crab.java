import greenfoot.*;

/**
 * Diese Klasse definiert eine Krabbe. Krabben leben am Strand.
 */
public class Crab extends Actor
{
    public void act()
    {
        // Füge hier deinen Code ein.
    }
}


