import greenfoot.*;  // (World, Actor, GreenfootImage und Greenfoot)

/**
 * Wurm. Ein Sandwurm. Sehr lecker. Vor allem Krabben mögen ihn.
 */
public class Worm extends Actor
{

}
