import greenfoot.*;

/**
 * Dies ist ein Strichmännchen. Lass es laufen und hüpfen.
 * 
 * @author 
 * @version 
 */
public class Stickman extends Actor
{
    /**
     * Das Strichmännchen agieren lassen.
     */
    public void act() 
    {        
    }    
}
