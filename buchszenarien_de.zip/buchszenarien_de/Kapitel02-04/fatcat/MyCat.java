import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

/**
 * MyCat ist deine eigene Katze. Lasse sie Dinge tun, indem du Code in diese act-Methode schreibst.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyCat extends Cat
{
    /**
     * Aktion - macht, was immer MyCat tun möchte.
     */
    public void act()
    {
    }    
}
