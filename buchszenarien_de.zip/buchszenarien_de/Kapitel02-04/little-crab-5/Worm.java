import greenfoot.*;

/**
* Wurm. Ein Sandwurm. Sehr lecker. Vor allem Krabben mögen ihn.
 */
public class Worm extends Actor
{
    
}
