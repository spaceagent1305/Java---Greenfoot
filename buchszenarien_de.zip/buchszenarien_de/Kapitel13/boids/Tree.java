import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

/**
 * Füge hier eine Beschreibung der Klasse Tree ein.
 * 
 * @author (dein Name) 
 * @version (eine Versionsnummer oder ein Datum)
 */
public class Tree extends SmoothActor
{
    /**
     * Aktion  - tue, was immer ein Baum so tun möchte. Diese Methode wird immer dann aufgerufen,
     * wenn in der Umgebung der Button 'Act' oder 'Run' gedrückt wird.
     */
    public void act() 
    {
        // Füge hier deinen Aktions-Code ein.
    }    
}
