import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

/**
  * Füge hier eine Beschreibung der Klasse BlackMarble ein.
 * 
 * @author (dein Name) 
 * @version (eine Versionsnummer oder Datum)
 */
public class BlackMarble extends Marble
{
    /**
     * Agiere  - tue, was immer eine schwarze Murmel so tun möchte. Diese Methode wird immer dann aufgerufen,
     * wenn in der Umgebung der Button 'Act' oder 'Run' gedrückt wird.
     */
    public void act() 
    {
        // Füge hier deinen Code für die Aktion ein.
    }    
}
