import greenfoot.World;
import greenfoot.Actor;

public class LiftController 
{
    public LiftController()
    {
    }

    public void act()
    {
        // noch nicht implementiert
    }

}
