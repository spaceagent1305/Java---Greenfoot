import greenfoot.*; 

/**
 * Ein einfacher Button.
 * 
 * @author Michael Kölling 
 * @version 1.0
 */
public class Button extends Actor
{
    /**
     * Aktion - nichts zu tun.
     */
    public void act() 
    {
    }    
}
