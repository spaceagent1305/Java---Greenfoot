import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

/**
 * Eine Begrenzung unserer Welt, um die linken und rechten Ränder zu verdecken.
 * 
 * @author Michael Kölling
 * @version 1.0
 */
public class Border extends Actor
{
    /**
     * Aktion - nichts zu tun. Dieses Objekt macht nichts.
     */
    public void act() 
    {
    }    
}
