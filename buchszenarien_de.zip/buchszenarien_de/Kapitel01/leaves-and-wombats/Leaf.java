import greenfoot.*;  // (World, Actor, GreenfootImage und Greenfoot)

/**
 * Leaf - eine Klasse, die Blätter repräsentiert.
 *
 * @author Michael Kölling
 * @version 2.0
 */
public class Leaf extends Actor
{
    public Leaf()
    {
    }
}
