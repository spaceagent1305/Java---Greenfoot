import greenfoot.*;  // (World, Actor, GreenfootImage und Greenfoot)

public class Key extends Actor
{
    /**
     * Erstellt eine neue Taste.
     */
    public Key()
    {
    }

    /**
     * Die Aktion f�r diese Taste.
     */
    public void act()
    {
    }
}

