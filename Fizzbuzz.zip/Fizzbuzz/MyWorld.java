import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1);      
    }

    public void fizzbuzz(int number)
    {
        if(number%15 == 0)              //falls number durch 15 teilbar 
        {
            System.out.print("Fizzbuzz!");
        } else if(number%3 == 0)          //falls number durch 3 teilbar
        {
            System.out.println("Fizz!");
        } else if(number%5 == 0)          //falls number durch 5 teilbar
        { 
            System.out.println("Buzz!");
        } 
        else                              //sonst soll immer weitergezählt werden
            System.out.println(number);
        number++;
    }
}
