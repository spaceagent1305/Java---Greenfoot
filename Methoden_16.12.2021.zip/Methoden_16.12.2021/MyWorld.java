import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{

    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
        double summand = Greenfoot.getRandomNumber(99)+1;
        double divisor = Greenfoot.getRandomNumber(103)+7;
        
        // Addition mit 17.5
        System.out.println("Addition mit 17.5: " + "17.5" + " + " + summand + " = " + addition(summand));
        
        //Ob Zahl durch 7 teilbar ist
        System.out.println("Folgende Zahl (Summe) durch 7 teilbar? => " + addition(summand) + " % 7 = " + isDivisableBySeven(divisor));
    }
    
    public double addition(double number) // Addiere fixe Zahl & gib die neue Zahl zurück
    {
        return 17.5 + number;
    }
    
    public boolean isDivisableBySeven(double number) // Die herausfindet, on eine zahl durch 7 teilbar ist, gib eine boolean zurück
    {
        return number%7 == 0;
    }
    
    public int intDivision(int num1, int num2) // Dividiere eine zahl mit eine andere und gib das ergebnis zurück (als int)
    {
        return num1 / num2;
    }
    
    public double doubleDivision(double num1, double num2) // Dividiere eine zahl mit eine andere und gib das ergebnis zurück (als double)
    {
        return num1 / num2;
    }
}
