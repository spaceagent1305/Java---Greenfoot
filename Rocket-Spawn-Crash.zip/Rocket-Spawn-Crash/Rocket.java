import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Rocket here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Rocket extends Actor
{   
    String crash = "Crash";
    /**
     * Act - do whatever the Rocket wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        move(10); //this = myRocket
        if(isAtEdge())
            this.turn(Greenfoot.getRandomNumber(75)+100); //Zufallszahl zw. 100 & 175
        
        if(this.isTouching(Rocket.class)) { //falls die Rakete mit einer anderen trifft
           System.out.println(crash);
           this.removeTouching(Rocket.class); //diese wird gelöscht
        }
    }
}

