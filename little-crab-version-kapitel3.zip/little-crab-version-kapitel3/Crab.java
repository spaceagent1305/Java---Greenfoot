import greenfoot.*;  // (World, Actor, GreenfootImage und Greenfoot)

/**
 * Diese Klasse definiert eine Krabbe. Krabben leben am Strand.
 * 
 * Version: 2
 * 
 * In dieser Version läuft die Krabbe mehr oder weniger zufällig am Strand herum.
 */
public class Crab extends Actor
{
    /** 
     *  Tut, was auch immer Krabben gerne tun. Diese Methode wird immer dann aufgerufen,
     *  wenn die Buttons 'Act' oder 'Run' in der Entwicklungsumgebung gedrückt werden.
     */
    public void act()
    {
        move(5);
        lookForWorm();
        checkKeypress();
    }
    
    public void lookForWorm()
    {
        if (isTouching(Worm.class))
        {
            removeTouching(Worm.class);
            Greenfoot.playSound("slurp.wav");
        }
    } 
    
    public void checkKeypress()
    {
        if (Greenfoot.isKeyDown("right"))
        {
            turn(4);
        }
        
        if (Greenfoot.isKeyDown("left"))
        {
            turn(-4);
        }
    }
}

