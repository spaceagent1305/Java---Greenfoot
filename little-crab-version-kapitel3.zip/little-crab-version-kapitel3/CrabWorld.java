import greenfoot.*;  // (Actor, World, Greenfoot, GreenfootImage)

public class CrabWorld extends World
{
    Crab myCrab = new Crab();
    Worm myWorm = new Worm();
    Lobster myLobster = new Lobster();
    private int xWormPosition = Greenfoot.getRandomNumber(300)+50;
    private int yWormPosition = Greenfoot.getRandomNumber(100)+10;
    private int xCrabPosition = Greenfoot.getRandomNumber(300)+50;
    private int yCrabPosition = Greenfoot.getRandomNumber(700)-50;
    private int xLobsterPosition = Greenfoot.getRandomNumber(300)+50;
    private int yLobsterPosition = Greenfoot.getRandomNumber(700)-50;
    /**
     * Erzeugt die Krabbenwelt (den Strand). Unsere Welt hat eine Größe 
     * von 560x560 Zellen, wobei jede Zelle nur ein Pixel groß ist.
     */
    public CrabWorld() 
    {
        super(560, 560, 1);
        addObject(myCrab, xCrabPosition, yCrabPosition);
        addObject(myWorm, xWormPosition, yWormPosition);
        addObject(myWorm, xWormPosition, yWormPosition);
        addObject(myLobster, xLobsterPosition, yLobsterPosition);
    }
}
