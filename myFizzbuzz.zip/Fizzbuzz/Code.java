import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Code here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Code extends Actor
{   
    /**
     * Act - do whatever the Code wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        for (int number = 1; number < 101;) //setze number auf 1; wiederhole, bis number 100 ist
        {
        { 
            if(number%15 == 0)              //falls number durch 15 teilbar 
          {
            System.out.print("Fizzbuzz!");
          } else if(number%3 == 0)          //falls number durch 3 teilbar
          {
            System.out.println("Fizz!");
          } else if(number%5 == 0)          //falls number durch 5 teilbar
          { 
            System.out.println("Buzz!");
          } 
          else                              //sonst soll immer weitergezählt werden
          System.out.println(number);
          number++;
        }
        }
    }
}
