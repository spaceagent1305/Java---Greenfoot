import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(600, 400, 1); 
    }

    /**
     * Zahl1 soll kleiner als Zahl2 sein
     * Dann soll eine Randomzahl übergeben werden: zahl1 <= randomZahl < zahl2
     */ 
    public int randomzahl(int zahl1, int zahl2)
    {
        return Greenfoot.getRandomNumber(zahl2-zahl1)+zahl1;
    }

    /**
     * ist die Zahl gerade => Hälfte der zahl wird zurückgeben
     * ist die Zahl ungerade => Dreifache der Zahl plus 1 (3*zahl + 1) wird zurückgeben
     */
    public int isEven(int num)
    {   
        if(num % 2 == 0)
        {
            return num = num / 2;
        }
        else 
        {
            return num = 3 * num + 1;
        }
    }

    public void fizzbuzz(int num)
    {
        if (num % 15 == 0)                //falls number durch 15 teilbar 
            System.out.println("Fizzbuzz");
        else if (num % 3 == 0)            //falls number durch 3 teilbar 
            System.out.println("Fizz");
        else if (num % 5 == 0)            //falls number durch 5 teilbar
            System.out.println("Buzz");
        else                              //sonst soll immer weitergezählt werden
            System.out.println(num); 
    }
}

