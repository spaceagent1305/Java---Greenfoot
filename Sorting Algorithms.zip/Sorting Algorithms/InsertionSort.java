import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class InsertionSort extends Sorter
{
    public void falseInsertionSort(int num)
    {
        initializeArray(num);
        fillArray();
        printUnsorted();
        InsertionSort(array);
        printSorted();
    }

    public void newInsertionSort(int num)
    {
        initializeArray(num);
        fillArray();
        printUnsorted();
        InsertionSortNew(array);
        printSorted();
    }

    private void InsertionSort(int[] array)
    {
        for (int i = 0; i < array.length; i++)
        {
            for (int n = i + 1; n < array.length; n++)
            {
                // Elemente abchecken!
                if (array[n] < array[i])
                {
                    // Swap!
                    swap(n,i);
                }
            }
        }
    }

    private void InsertionSortNew(int[] array) 
    {   
        for (int j = 1; j < array.length; j++) 
        {  
            int key = array[j];  
            int i = j-1;  
            while ( (i > -1) && ( array [i] > key ) ) 
            {  
                array [i+1] = array [i];  
                i--;  
            }  
            array[i+1] = key;  
        }  
    }
}