import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Sorter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sorter extends Actor
{
    int[] array;
    public void initializeArray(int num)
    {
        array = new int[num];
    }

    public void fillArray()
    {
        for(int i = 0; i < array.length; i++)
        {
            array[i] = Greenfoot.getRandomNumber(20);
        }
    }

    public void printArray()
    {
        for(int i = 0; i < array.length; i++)
        {
            System.out.print(array + " ");
        }
    }

    public void printUnsorted()
    {
        System.out.print("Unsorted: " + "[ ");
        for(int i = 0; i < array.length; i++)
        {
            System.out.print(array[i] + ", ");
        }
        System.out.println("]");
    }

    public void printSorted()
    {
        System.out.print("Sorted: " + "[ ");
        for(int i = 0; i < array.length; i++)
        {
            System.out.print(array[i] + ", ");
        }
        System.out.println("]");
    }

    public void swap(int num1, int num2)
    {
        int n = array[num1];
        array[num2] = array[num1];
        n = array[num2];
    }
}
