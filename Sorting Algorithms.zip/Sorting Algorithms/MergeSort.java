import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class MergeSort extends Sorter
{   
    public void MergeSort(int num)
    {
        initializeArray(num);
        fillArray();
        printUnsorted();
        mergeSort(array); 
        printSorted();
    }

    private void mergeSort(int[] inputArray) //rekursive Version
    {
        int inputLength = inputArray.length;  // Variale zur mehrfachen Nutzung

        if (inputLength < 2) //weil bereits sortiert 
        {
            return;
        }
        
        // divide array in 2 subarrays:
        int midIndex = inputLength / 2; 
        int[] leftHalf = new int[midIndex];
        int[] rightHalf = new int[inputLength - midIndex]; // aufpassen bei un-/geraden Zahlen AUSNAHME

        // copy nums from array to leftHalf-subarray (von 0 => mid)
        for (int i = 0; i < midIndex; i++) { 
            leftHalf[i] = inputArray[i];
        }
        // copy nums from array to rightHalf-subarray (von mid => length)
        // un-/gerade Zahlen AUSNAHME!
        for (int i = midIndex; i < inputLength; i++) {
            rightHalf[i - midIndex] = inputArray[i];
        }

        // merge each of these 2 subarrays:
        mergeSort(leftHalf);
        mergeSort(rightHalf);

        // merge 2 subarrays => array
        merge(inputArray, leftHalf, rightHalf); // call merged Array
    }

    private void merge (int[] inputArray, int[] leftHalf, int[] rightHalf) {
        int leftSize = leftHalf.length; //Gr��e von L-Array
        int rightSize = rightHalf.length; //Gr��e von R-Array

        int l = 0, r = 0, mergedArray = 0; // Variables for walking through left, right & merged Array 

        // Loop each of 2 subarrays adding the lower of the 2 values => merged Array (until running out of elements)
        while (l < leftSize && r < rightSize) 
        {
            if (leftHalf[l] <= rightHalf[r]) { // Vergleiche 1 Zahl jeweils 
                inputArray[mergedArray] = leftHalf[l];
                l++; // gehe weiter zur n�chsten Zahl (L-Array)
            }
            else {
                inputArray[mergedArray] = rightHalf[r];
                r++; // gehe weiter zur n�chsten Zahl (R-Array)
            }
            mergedArray++; // setting the next value
        }

        // Loop & add any remaining elements => merged Array
        while (l < leftSize) 
        {
            inputArray[mergedArray] = leftHalf[l];
            l++;
            mergedArray++;
        }

        while (r < rightSize) 
        {
            inputArray[mergedArray] = rightHalf[r];
            r++;
            mergedArray++;
        }
    }
}